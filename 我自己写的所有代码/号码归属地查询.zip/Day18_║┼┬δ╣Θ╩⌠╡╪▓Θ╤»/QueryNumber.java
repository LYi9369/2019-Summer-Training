//package Day18_��������ز�ѯ;
package Day18_号码归属地查询;

import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;

public class QueryNumber {
	public static void main(String[] args) {
		String host = "http://imobile.market.alicloudapi.com";
		String path = "/mobile/query";
		String method = "GET";
		String appcode = "11f711c09207449988a20967d8287ba3";
		Map<String, String> headers = new HashMap<String, String>();
		// �����header�еĸ�ʽ(�м���Ӣ�Ŀո�)ΪAuthorization:APPCODE
		// 83359fd73fe94948385f570e3c139105
		headers.put("Authorization", "APPCODE " + appcode);
		Map<String, String> querys = new HashMap<String, String>();
		querys.put("number", "13988888888");

		String jsonResult = "";

		try {
			/**
			 * ��Ҫ��ʾ����: HttpUtils���
			 * https://github.com/aliyun/api-gateway-demo-sign
			 * -java/blob/master/src
			 * /main/java/com/aliyun/api/gateway/demo/util/HttpUtils.java ����
			 * 
			 * ��Ӧ�����������
			 * https://github.com/aliyun/api-gateway-demo-sign-java/blob
			 * /master/pom.xml
			 */
			HttpResponse response = HttpUtils.doGet(host, path, method,
					headers, querys);
			System.out.println(response.toString());
			// ��ȡresponse��body
			jsonResult = EntityUtils.toString(response.getEntity());
			JSONObject obj = JSONObject.fromObject(jsonResult);
			Integer ret = (Integer) obj.get("ret");
			System.out.println(ret);
			if (ret.equals(200)) {
				System.out.println("�������");
				JSONObject obj1 = (JSONObject) obj.get("data");
				System.out.println(obj1.get("area_num"));
				System.out.println(obj1.get("isp"));
				System.out.println(obj1.get("prov"));
				System.out.println(obj1.get("city"));
			} else {
				System.out.println("��ѯʧ��");
			}

			// System.out.println(EntityUtils.toString(response.getEntity()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
