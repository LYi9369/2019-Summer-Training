//package Day19_���֤��ѯ;
package Day19_身份证查询;

import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;

//import Day18_��������ز�ѯ.HttpUtils;

public class QueryID {
	public static void main(String[] args) {
		String host = "http://idcardinfo.market.alicloudapi.com";
		String path = "/lianzhuo/queryidcard";
		String method = "GET";
		String appcode = "11f711c09207449988a20967d8287ba3";
		Map<String, String> headers = new HashMap<String, String>();
		// �����header�еĸ�ʽ(�м���Ӣ�Ŀո�)ΪAuthorization:APPCODE
		// 83359fd73fe94948385f570e3c139105
		headers.put("Authorization", "APPCODE " + appcode);
		Map<String, String> querys = new HashMap<String, String>();
		querys.put("id", "341202199101010552");
		String jsonResult = "";

		try {
			/**
			 * ��Ҫ��ʾ����: HttpUtils���
			 * https://github.com/aliyun/api-gateway-demo-sign
			 * -java/blob/master/src
			 * /main/java/com/aliyun/api/gateway/demo/util/HttpUtils.java ����
			 * 
			 * ��Ӧ�����������
			 * https://github.com/aliyun/api-gateway-demo-sign-java/blob
			 * /master/pom.xml
			 */
			HttpResponse response = HttpUtils.doGet(host, path, method,
					headers, querys);
			System.out.println(response.toString());
			// ��ȡresponse��body
			jsonResult = EntityUtils.toString(response.getEntity());
			JSONObject obj = JSONObject.fromObject(jsonResult);
			JSONObject obj1 = (JSONObject) obj.get("resp");
			Integer code = (Integer) obj1.get("code");
			if (code.equals(0)) {
				System.out.println("���Լ������");
				JSONObject obj2 = (JSONObject) obj.get("data");

				System.out.println(obj2.get("origin"));
				System.out.println(obj2.get("gender"));
				System.out.println(obj2.get("bornday"));
			} else {
				System.out.println("��ѯʧ��");
			}
			// System.out.println(EntityUtils.toString(response.getEntity()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
