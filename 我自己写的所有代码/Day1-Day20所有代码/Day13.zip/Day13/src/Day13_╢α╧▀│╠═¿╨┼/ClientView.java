package Day13_���߳�ͨ��;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * ClientView �Ǹ���ͻ��˽�����ʾ�� swing �¼����� ���̼����Ͷ��߳̽ӿ�
 * 
 * @author aaaa
 *
 */
public class ClientView extends JFrame implements KeyListener, ActionListener, Runnable {
	// �ȶ��� ����ϵĿؼ�
	private JTextArea textArea;// �ı���
	private JTextField textField, tfName;// �ı���
	private JButton btnSend;
	private JLabel lable;
	private JPanel jp1, jp2;
	private JScrollPane scorllPane;// ������

	private Socket socket = null;
	// �������������
	private DataInputStream dis = null;
	private DataOutputStream dos = null;
	private static ClientView view;

	public ClientView() {
		initView();
		try {
			socket = new Socket("localhost", 9090);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void initView() {
		// ��ɴ��崴������
		textArea = new JTextArea(20, 20);
		// �����ı����ܱ��༭
		textArea.setEditable(false);
		// ���ı���ŵ���������
		scorllPane = new JScrollPane(textArea);
		textField = new JTextField(15);
		// ���Ӽ��̼���
		textField.addKeyListener(this);
		btnSend = new JButton("����");
		btnSend.addActionListener(this);
		lable = new JLabel("�ǳ�");
		tfName = new JTextField(18);
		jp1 = new JPanel();
		jp2 = new JPanel();
		jp1.add(lable);
		jp1.add(tfName);
		jp1.setLayout(new FlowLayout(FlowLayout.CENTER));
		jp2.add(textField);
		jp2.add(btnSend);
		jp2.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.add(jp1, BorderLayout.NORTH);
		this.add(scorllPane, BorderLayout.CENTER);
		add(jp2, BorderLayout.SOUTH);
		// ���ñ���
		setTitle("������");
		setSize(500, 500);
		setLocation(450, 150);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				if (socket != null) {
					try {
						socket.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
				if (dis != null) {
					try {
						dis.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
				if (dos != null) {
					try {
						dos.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
	}

	/**
	 * ʵ�ַ�����Ϣ�ļ��������ͷ�����Ϣ�ķ��� �ڷ�����Ϣ��ͬʱҪʵ�ְ�������Ϣ�ŵ���Ϣ��ʾ�ռ�
	 * 
	 * @return
	 */
	public JTextArea getTextArea() {
		return textArea;
	}

	public void setTextArea(JTextArea textArea) {
		this.textArea = textArea;
	}

	public JTextField getTextField() {
		return textField;
	}

	public void setTextField(JTextField textField) {
		this.textField = textField;
	}

	public JTextField getTfName() {
		return tfName;
	}

	public void setTfName(JTextField tfName) {
		this.tfName = tfName;
	}

	public JButton getBtnSend() {
		return btnSend;
	}

	public void setBtnSend(JButton btnSend) {
		this.btnSend = btnSend;
	}

	public JLabel getLable() {
		return lable;
	}

	public void setLable(JLabel lable) {
		this.lable = lable;
	}

	public JPanel getJp1() {
		return jp1;
	}

	public void setJp1(JPanel jp1) {
		this.jp1 = jp1;
	}

	public JPanel getJp2() {
		return jp2;
	}

	public void setJp2(JPanel jp2) {
		this.jp2 = jp2;
	}

	public JScrollPane getScorllPane() {
		return scorllPane;
	}

	public void setScorllPane(JScrollPane scorllPane) {
		this.scorllPane = scorllPane;
	}

	public Socket getSocket() {
		return socket;
	}

	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	public DataInputStream getDis() {
		return dis;
	}

	public void setDis(DataInputStream dis) {
		this.dis = dis;
	}

	public DataOutputStream getDos() {
		return dos;
	}

	public void setDos(DataOutputStream dos) {
		this.dos = dos;
	}

	public ClientView getView() {
		return view;
	}

	// �¼�����
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == btnSend) {
			sendMsg();
		}
	}

	public void sendMsg() {
		String s = textField.getText();
		if (!s.equals("")) {
			textField.setText("");
			textArea.append("��(" + tfName.getText() + ")\n" + s + "\n");
			// ʹ�������������ݴ���
			try {
				dos = new DataOutputStream(socket.getOutputStream());
				// ����д����
				dos.writeUTF(tfName.getText() + "#" + s);
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			sendMsg();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	// ���շ�������ת��������Ϣ
	@Override
	public void run() {
		try {
			dis = new DataInputStream(socket.getInputStream());
			while (true) {
				String strings = dis.readUTF();
				String[] s = strings.split("#");
				System.out.println(s);
				textArea.append(s[0] + "\r\n" + s[1] + "\r\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		view = new ClientView();
		Thread thread = new Thread(view);
		thread.start();
	}
}
