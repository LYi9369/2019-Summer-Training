package js����;

//import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
//import com.mysql.jdbc.Statement;

public class MySql�޸Ĳ��� {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/test1";
		String user = "root";
		String pwd = "123456";
		Connection con = null;
		Statement state = null;
		try {//��������
			Class.forName("com.mysql.jdbc.Driver");
			// ��������
			con = DriverManager.getConnection(url, user, pwd);
			// ����SQL
			String sql = "UPDATE  user SET u_name = 'ABC' WHERE u_id = 2";
			// ����statement����
			state = con.createStatement();
			int count = state.executeUpdate(sql);
			if (count == 0) {
				System.out.println("�޸�ʧ�ܣ�");
			} else {
				System.out.println("�޸ĳɹ���");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (state != null) {
					state.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (con != null) {
					con.close();

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
