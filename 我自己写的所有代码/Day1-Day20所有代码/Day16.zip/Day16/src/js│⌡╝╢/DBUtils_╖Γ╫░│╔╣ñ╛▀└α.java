package js����;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class DBUtils_��װ�ɹ����� {

	private static String url;
	private static String driver;
	private static String user;
	private static String pwd;
	// ʹ�þ�̬��������properties�ļ�����ֻ֤��һ��������Ϣ����
	static {
		Properties pro = new Properties();
		try {
			InputStream is = new FileInputStream("conn.properties");
			pro.load(is);
			// Connection con = null;
			// pro.load(DBUtils_��װ�ɹ�����.class.getResourceAsStream("conn.properties"));
			// pro.load(is);
			// ��ȡ��Ϣ
			url = pro.getProperty("url");
			System.out.println(url);
			driver = pro.getProperty("driver");
			System.out.println(driver);
			user = pro.getProperty("user");
			System.out.println(user);
			pwd = pro.getProperty("pwd");
			System.out.println(pwd);
			is.close();
			Class.forName(driver);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Connection getStatement() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(url, user, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public static Statement getStatement(Connection con) {
		Statement state = null;
		try {
			if (con != null) {
				state = con.createStatement();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return state;
	}

	public static void closeAll(Connection con, Statement state, ResultSet res) {
		try {
			if (state != null) {
				state.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (con != null) {
				con.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		DBUtils_��װ�ɹ����� db = new DBUtils_��װ�ɹ�����();
	}
}
