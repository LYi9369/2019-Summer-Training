package Day8_XML����;

public class AddServlet implements Servlet{

	public AddServlet() {
		System.out.println("AddServlet.AddServlet()");
	}

	@Override
	public void service() {
		System.out.println("AddServlet.service()");
	}

}
