package Day8_XML����;

public class LoginOutServlet implements Servlet{
    
	public LoginOutServlet() {
		System.out.println("LoginOutServlet.LoginOutServlet()");
	}

	@Override
	public void service() {
		System.out.println("LoginOutServlet.service()");
	}

}
