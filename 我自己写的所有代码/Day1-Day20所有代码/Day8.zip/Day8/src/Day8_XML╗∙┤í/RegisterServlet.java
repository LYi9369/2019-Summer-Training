package Day8_XML����;


public class RegisterServlet implements Servlet{
	
	public RegisterServlet() {
	System.out.println("RegisterServlet.RegisterServlet()");
	}

	@Override
	public void service() {
		System.out.println("RegisterServlet.service()");
	}

}
