package Day8_XML����;

import java.util.Map;

public class XMLUtil {
	public static void main(String[] args) {
       Map<Integer, String> map=readXML("web.xml");
	}

	public static Map<Integer, String> readXML(String file) {
		
		return null;
	}
}
