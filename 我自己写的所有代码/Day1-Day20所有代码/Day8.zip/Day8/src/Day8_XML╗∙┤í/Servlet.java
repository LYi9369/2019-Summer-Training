package Day8_XML����;

public interface Servlet {
   public void service();
}
