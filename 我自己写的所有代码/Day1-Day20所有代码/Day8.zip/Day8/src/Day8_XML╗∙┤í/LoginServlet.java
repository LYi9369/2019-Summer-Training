package Day8_XML����;

public class LoginServlet implements Servlet{
   
	public LoginServlet() {
		System.out.println("LoginServlet.LoginServlet()");
	}

	@Override
	public void service() {
	System.out.println("LoginServlet.service()");
		
	}

}
