package Day11_GUIѧϰ;

import javax.swing.JFrame;

class Test {
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setBounds(400, 200, 400, 300);

	}
}
