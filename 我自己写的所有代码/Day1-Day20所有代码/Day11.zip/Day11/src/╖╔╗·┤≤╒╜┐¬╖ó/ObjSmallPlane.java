package �ɻ���ս����;
public class ObjSmallPlane extends FlyingObj implements Enemy{

	//�趨С�ɻ����ƶ��ٶ�
	public int speed=1;
	
	public ObjSmallPlane() {
		  this.image=Factory.imgSmallPlane;
			width=image.getWidth();
			height=image.getHeight();
			y=-height;
			x=(int) (Math.random()*(Factory.jframeWidth-width));
			
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	@Override
	public void step() {
		y+=speed;
	}

	@Override
	public boolean OutOfBands() {
		return false;
	}

	@Override
	public int getScore() {
		return 5;
	}

}
