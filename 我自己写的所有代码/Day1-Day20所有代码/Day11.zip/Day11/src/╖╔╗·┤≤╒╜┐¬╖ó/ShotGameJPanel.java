package �ɻ���ս����;

import java.awt.Graphics;

import javax.swing.JPanel;

public class ShotGameJPanel extends JPanel implements Runnable{

	//��Ա����
	Factory factory;
	Thread t;
	public ShotGameJPanel() {
		factory=new Factory();
		
		t=new Thread(this);
		t.start();
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		factory.paintbackground(g);
		factory.paintHero(g);
		factory.paintScore(g);
		factory.paintState(g);
	}

	@Override
	public void run() {
		
	}
}
