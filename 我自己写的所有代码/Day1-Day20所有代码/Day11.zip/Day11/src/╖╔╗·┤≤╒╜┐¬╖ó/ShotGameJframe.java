package �ɻ���ս����;

import java.awt.HeadlessException;

import javax.swing.JFrame;

public class ShotGameJframe extends JFrame{

	public ShotGameJframe()  {
	    this.setTitle("�ɻ���ս");
	    this.setBounds(Factory.jframeX, Factory.jframeY, Factory.jframeWidth, Factory.jframeHeight);
	    //���ô����С���ɸı�
	      this.setResizable(false);
	    //���ô���ɼ�
	      ShotGameJPanel my=new ShotGameJPanel();
	       this.add(my);
	    setVisible(true);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
   public static void main(String[] args) {
	  new ShotGameJframe();
}
	
}
