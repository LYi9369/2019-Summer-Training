package Day10_GUI����;

public class TestButton {
public static void main(String[] args) {
	
}
}
