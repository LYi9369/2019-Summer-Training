package Day10_GUI����;

import java.awt.Dimension;
import java.awt.Point;

public class Test {
	public static void main(String[] args) {

		Dimension d = new Dimension(400, 300);
		// f.setSize(d);
		Point p = new Point(400, 200);
		// f.setLocation(p);
		// f.setVisible(true);

	}
}
