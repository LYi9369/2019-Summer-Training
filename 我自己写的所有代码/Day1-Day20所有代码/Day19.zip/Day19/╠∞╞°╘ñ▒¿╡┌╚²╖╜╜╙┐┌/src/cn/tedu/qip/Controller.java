package cn.tedu.qip;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Controller extends HttpServlet {

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// 设置编码格式
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		// 设置响应头的编码格式
		resp.setContentType("text/html,charset=utf-8");
		String uname = req.getParameter("number");
		System.out.println(uname);
		QIPs qip = new QIPs();
		String result = qip.QueryIP(uname);
		System.out.println(result);
		// 将数据传送到前台
		resp.getWriter().write(result);
	}

}
