package Day6_�ϴ�;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class MyTestClient {
	public static void main(String[] args) throws UnknownHostException, IOException {
		// �����ͻ��˶���
		Socket client = new Socket(InetAddress.getLocalHost(), 8888);
		// ������
		BufferedInputStream bis = new BufferedInputStream(new FileInputStream("c:/hello.txt"));
		BufferedOutputStream bos = new BufferedOutputStream(client.getOutputStream());
		// ʹ����
		byte[] buf = new byte[1024];
		int len = bis.read(buf);
		while (len != -1) {
			// д
			bos.write(buf, 0, len);
			// ��
			len = bis.read(buf);
		}
		// �ر���
		bis.close();
		bos.close();
		client.close();
	}
}
