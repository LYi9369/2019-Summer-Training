package Day7_�߳�ͨ��;

public class MyComsumerRunnable implements Runnable {
	private Product product;

	public MyComsumerRunnable() {
		super();
		// TODO �Զ����ɵĹ��캯�����
	}

	public MyComsumerRunnable(Product product) {
		super();
		this.product = product;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public void run() {
		while (true) {
			synchronized (product) {
				if (product.flag == false) {
					try {
						product.wait();
					} catch (Exception e) {
						// TODO: handle exception
						e.printStackTrace();
					}
				}
			}
			System.out.println("�����ߴӲֿ�����һ����Ʒ������" + product.getName() + "===" + product.getColor());
			product.flag = false;
			product.notify();
		}
	}

}
