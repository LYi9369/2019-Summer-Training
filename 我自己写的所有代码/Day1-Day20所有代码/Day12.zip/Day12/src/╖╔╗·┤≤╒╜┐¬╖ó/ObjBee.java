package �ɻ���ս����;
public class ObjBee extends FlyingObj implements Award{
	
	  //�趨�ƶ��ٶ�
	  private int xSpeed=1;
	  private int ySpeed=1;
	  
	  public ObjBee() {
		  this.image=Factory.imgBee;
			width=image.getWidth();
			height=image.getHeight();
			y=-height;
			x=(int) (Math.random()*(Factory.jframeWidth-width));
			awardType=(int) (Math.random()*2);
	}

	//set get����
	  public int getxSpeed() {
		return xSpeed;
	}

	public void setxSpeed(int xSpeed) {
		this.xSpeed = xSpeed;
	}

	public int getySpeed() {
		return ySpeed;
	}

	public void setySpeed(int ySpeed) {
		this.ySpeed = ySpeed;
	}

	public int getAwardType() {
		return awardType;
	}

	public void setAwardType(int awardType) {
		this.awardType = awardType;
	}

	//�趨����ֵ 
	  public int awardType=0;
	  //�ƶ� 
	  //�Ƿ�Խ��
	  //�ӵ�����
	  //��ȡ����ֵ

	@Override
	public int getType() {
		
		return awardType;
	}

	@Override
	public void step() {
		
		
	}

	@Override
	public boolean OutOfBands() {
	
		return false;
	}
}
