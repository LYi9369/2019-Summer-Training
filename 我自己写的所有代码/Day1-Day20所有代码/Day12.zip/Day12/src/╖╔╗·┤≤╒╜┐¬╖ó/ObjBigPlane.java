package �ɻ���ս����;
public class ObjBigPlane extends FlyingObj implements Enemy{
   
	 //�趨��ɻ����ƶ��ٶ�
	public int speed=1;
	@Override
	public void step() {
		y+=speed;
	}

	public ObjBigPlane() {
		  this.image=Factory.imgBigPlane;
			width=image.getWidth();
			height=image.getHeight();
			y=-height;
			x=(int) (Math.random()*(Factory.jframeWidth-width));
			
	}

	@Override
	public boolean OutOfBands() {
		return false;
	}

	@Override
	public int getScore() {
		return 5;
	}

}
