package �ɻ���ս����;
public class ObjAirDrop extends FlyingObj implements Award{
    
	
	  //�趨�ƶ��ٶ�
	  private int xSpeed=1;
	  private int ySpeed=1;
	  
	  //�趨����ֵ 
	  public int awardType=0;
  //�޲εĹ��췽��
	public ObjAirDrop() {
		this.image=Factory.imgAirDrop;
		width=image.getWidth();
		height=image.getHeight();
		y=-height;
		x=(int) (Math.random()*(Factory.jframeWidth-width));
		awardType=(int) (Math.random()*2);
	}

	public int getxSpeed() {
		return xSpeed;
	}

	public void setxSpeed(int xSpeed) {
		this.xSpeed = xSpeed;
	}

	public int getySpeed() {
		return ySpeed;
	}

	public void setySpeed(int ySpeed) {
		this.ySpeed = ySpeed;
	}

	public int getAwardType() {
		return awardType;
	}

	public void setAwardType(int awardType) {
		this.awardType = awardType;
	}

	@Override
	public void step() {
		
	}

	@Override
	public boolean OutOfBands() {
		
		return false;
	}

	@Override
	public int getType() {
		return awardType;
	}


	  
	  
}

