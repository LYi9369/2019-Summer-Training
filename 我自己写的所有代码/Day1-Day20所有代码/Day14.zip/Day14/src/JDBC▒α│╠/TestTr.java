package JDBC���;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TestTr {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/test1?useUnicode=true&characterEncoding=utf-8";
		String user = "root";
		String pwd = "123456";
		Connection con = null;
		Statement stat = null;
		Statement stat1 = null;
		String driver = "com.mysql.jdbc.Driver";
		// ��������
		try {
			Class.forName(driver);
			// ��������
			con = DriverManager.getConnection(url, user, pwd);
			String sql = "update t_account set m_money=m_money-1000 where m_id=4";
			String sql1 = "update t_account set m_money=m_money+1000 where m_id=2";
			con.setAutoCommit(false);
			stat = con.createStatement();
			stat1 = con.createStatement();
			// ִ��sql
			int count = stat.executeUpdate(sql);
			int count1 = stat1.executeUpdate(sql1);
			if (count == 0 || count1 == 0) {
				System.out.println("ת��ʧ��");
				con.rollback();
				// �ع�
			} else {
				// �ύ����
				con.commit();
				System.out.println("ת�˳ɹ�");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				stat1.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
}
