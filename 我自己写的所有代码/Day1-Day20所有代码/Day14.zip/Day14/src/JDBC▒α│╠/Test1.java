package JDBC���;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * �޸Ĳ���
 * 
 * @author aaaa map: key value Properties
 */
public class Test1 {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/test1?useUnicode=true&characterEncoding=utf-8";
		String user = "root";
		String pwd = "123456";
		Connection con = null;
		Statement stat = null;
		try {
			// ��������
			Class.forName("com.mysql.jdbc.Driver");
			// ��������
			con = DriverManager.getConnection(url, user, pwd);
			// ����sql
			String sql = "UPDATE user set u_name='������' WHERE u_id=5";
			// ����ִ��������
			stat = con.createStatement();
			int count = stat.executeUpdate(sql);
			if (count == 0) {
				System.out.println("�޸�ʧ��");
			} else {
				System.out.println("�޸ĳɹ�");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stat != null) {
					stat.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
