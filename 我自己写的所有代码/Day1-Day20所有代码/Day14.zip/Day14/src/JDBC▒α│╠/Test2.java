package JDBC���;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Test2 {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/test1?useUnicode=true&characterEncoding=utf-8";
		String user = "root";
		String pwd = "123456";
		Connection con = null;
		Statement stat = null;

		try {
			// ��������
			Class.forName("com.mysql.jdbc.Driver");
			// ��������
			con = DriverManager.getConnection(url, user, pwd);
			// ����sql
			String sql = "DELETE from user where u_id=5";
			// ����ִ��������
			stat = con.createStatement();
			// ִ��sql���
			int count = stat.executeUpdate(sql);
			if (count == 0) {
				System.out.println("ɾ��ʧ��");
			} else {
				System.out.println("ɾ���ɹ�");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
