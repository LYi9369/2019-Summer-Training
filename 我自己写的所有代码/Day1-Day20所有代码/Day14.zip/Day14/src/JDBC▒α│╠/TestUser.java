package JDBC���;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestUser {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("*****ģ��ע���¼*****");
			System.out.println("1����¼");
			System.out.println("2��ע��");
			System.out.println("3���˳�");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("��¼");
				login();
				break;
			case 2:
				Register();
				break;
			case 3:
				System.exit(0);
				break;
			default:
				break;
			}
		}
	}

	private static void login() {

	}

	/**
	 * ע��
	 * 
	 * @throws SQLException
	 */
	public static void Register() {
		Scanner sc = new Scanner(System.in);
		System.out.println("�������û�����");
		String name = sc.next();
		System.out.println("���������룺");
		String pwd = sc.next();
		Connection con = null;
		Statement stat = null;
		try {
			con = DBUtils.getCon();
			String sql = "insert into user(u_name,u_pwd) values('" + name + "','" + pwd + "')";
			stat = DBUtils.getStat(con);
			int count = stat.executeUpdate(sql);
			if (count == 0) {
				System.out.println("ע��ʧ��");
			} else {
				System.out.println("ע��ɹ�");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtils.closeAll(con, stat, null);
		}
	}
}
