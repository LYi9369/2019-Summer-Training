package JDBC���;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * ��ɲ�ѯ����
 * 
 * @author aaaa
 *
 */
public class Test3 {
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/test1?useUnicode=true&characterEncoding=utf-8";
		String user = "root";
		String pwd = "123456";
		Connection con = null;
		Statement stat = null;
		String driver = "com.mysql.jdbc.Driver";
		ResultSet res = null;
		try {
			// ��������
			Class.forName(driver);
			// ��������
			con = DriverManager.getConnection(url, user, pwd);
			// ����sql
			String sql = "SELECT * from user";
			// ����ִ��������
			stat = con.createStatement();
			// ִ��sql
			res = stat.executeQuery(sql);
			// ���������
			while (res.next()) {
				System.out.println(res.getInt("u_id") + "\t" + res.getString("u_name") + "\t" + res.getString("u_pwd"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				res.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
}
