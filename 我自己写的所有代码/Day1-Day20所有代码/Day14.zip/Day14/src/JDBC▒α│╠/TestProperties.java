package JDBC���;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

/**
 * ��ʶһ��Properties key value ��ֵ�� Properities key value Ҫ����String һ�������ļ����ʹ��
 * ����������Ϣ
 * url=jdbc:mysql://localhost:3306/test1?useUnicode=true&characterEncoding=utf-8
 * 
 * @author aaaa
 *
 */
public class TestProperties {
	public static void main(String[] args) throws IOException {
		// write();
		Properties pro = new Properties();
		InputStream is = new FileInputStream("conn.properties");
		pro.load(is);
		String value = pro.getProperty("url");
		System.out.println(value);
	}

	public static void write() throws IOException {
		Properties pro = new Properties();
		pro.setProperty("url", "jdbc:mysql://localhost:3306/test1?useUnicode=true&characterEncoding=utf-8");
		pro.setProperty("driver", "com.mysql.jdbc.Driver");
		OutputStream os = new FileOutputStream("conn.properties");
		pro.store(os, "user infomation");
		os.close();
	}
}
