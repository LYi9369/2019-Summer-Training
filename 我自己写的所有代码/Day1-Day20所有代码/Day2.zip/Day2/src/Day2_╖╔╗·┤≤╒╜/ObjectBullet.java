package Day2_�ɻ���ս;

public abstract class ObjectBullet extends FlyObject {

}
