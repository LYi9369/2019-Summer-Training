package Day2_�ɻ���ս;

public abstract class FlyObject extends ObjectDrop {
	int x;
	int y;// ������
	int width;
	int height;

	public abstract void step();

	public abstract boolean OutOfBands();
	// public boolean shotBy();

}
