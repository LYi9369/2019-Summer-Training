package Day2_����ƽ̨;

import java.util.List;

public interface ProductDao {

	List<Product> findAll();

	Product findById(int id);

}
