package Day3_IO����;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.sound.midi.Instrument;
import javax.sound.midi.Patch;
import javax.sound.midi.Soundbank;
import javax.sound.midi.SoundbankResource;

public class �����ļ� {
	public static void main(String[] args) {
		copyFile("c:/readme.txt", "c:/README.txt");
	}

	public static void copyFile(String sourceFile, String destFile) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		try {
			// ������
			bis = new BufferedInputStream(new FileInputStream(new File(sourceFile)));
			bos = new BufferedOutputStream(new FileOutputStream(new File(destFile)));

			// ʹ����
			byte[] buf = new byte[1024];
			// ��
			int len = bis.read();
			while (len != -1) {
				// д
				bos.write(buf, 0, len);
				len = bis.read(buf);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			if (bis != null)
				// �ر���
				bis.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			if (bos != null)
				// �ر���
				bos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
