package Day1_ũ��ţ����;

import java.util.Iterator;

public class Cattle {

	private int age;
	private boolean sex;
	public static boolean MALE = true;// true ���ǹ�ţ
	public static boolean FEMALE = false;// false ����ĸţ

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean isSex() {
		return sex;
	}

	public void setSex(boolean sex) {
		this.sex = sex;
	}

	public Cattle() {
		this.setAge(1);
		this.setSex(Math.random() < 0.5);
	}

	// �Ƿ���
	public boolean alive() {
		return this.age < 16;
	}

	// �Ƿ�����ţ
	public boolean bornning() {
		return this.sex == FEMALE && this.age % 3 == 0;
	}

	public Cattle grows() {
		this.age++;
		if (alive() && bornning()) {
			Cattle newBornCattle = new Cattle();
			return newBornCattle;
		} else {
			return null;
		}
	}

	@Override
	public String toString() {
		return "Cattle [age=" + age + ", sex=" + sex + "]";
	}

	public static void main(String[] args) {
		Cattle c = new Cattle();
		System.out.println(c);
			
			for(int i=0; i<21; i++){
			}
			
	}
}
