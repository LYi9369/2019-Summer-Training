package Day1;

public class pro1 {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		for (int i = 0; i < 3; i++) {
			int num = (int) (Math.random() * 15 + 3);

			if (num > 9 && num <= 11)
				System.out.println("���Ƚ�\n");
			else if (num >= 12 && num <= 14)
				System.out.println("���Ƚ�\n");
			else if (num == 15)
				System.out.println("һ�Ƚ�\n");
		}

		for (int j = 1; j < 1001; j++) {
			if (j % 5 == 0) {
				// for(int k=0; k<6; k++){
				System.out.println(j + "   ");
				// }
			}
		}

	}

}
