package Day5_TCP������2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client {
	public static void main(String[] args) throws IOException {
		Socket client = new Socket("192.168.43.13", 8888);
		String str;
		Scanner input = new Scanner(System.in);
		OutputStream os = client.getOutputStream();
		DataOutputStream dos = new DataOutputStream(os);

		// ���ܷ������˵���Ϣ
		InputStream is = client.getInputStream();
		DataInputStream dis = new DataInputStream(is);
		String serverStr = dis.readUTF();

		while (!(str = input.next()).equals("#")) {
			dos.writeUTF(str);
			System.out.println("�ͻ�ip��" + client.getInetAddress().getHostAddress() + "˵��" + serverStr);
		}

		dis.close();
		dos.close();
		client.close();

	}
}
