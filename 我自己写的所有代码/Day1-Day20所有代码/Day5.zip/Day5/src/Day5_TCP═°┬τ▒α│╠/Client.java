package Day5_TCP������;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client {
	public static void main(String[] args) throws IOException {
		// ��ȡ�ͻ��˶���
		Socket client = new Socket("192.168.43.13", 88889);
		Scanner input = new Scanner(System.in);
		String str = null;

		// ��ȡ�����
		OutputStream os = client.getOutputStream();
		while (!(str = input.next()).equals("#")) {
			os.write(str.getBytes());
		}

		os.close();
		client.close();
	}
}
