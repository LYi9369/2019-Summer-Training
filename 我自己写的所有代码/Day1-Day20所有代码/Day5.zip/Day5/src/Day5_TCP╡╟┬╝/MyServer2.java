package Day5_TCP��¼;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class MyServer2 {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		ServerSocket server = new ServerSocket();
		Socket client = server.accept();
		InputStream is = client.getInputStream();
		ObjectInputStream ois = new ObjectInputStream(is);
		User user = (User) ois.readObject();
		System.out.println("�ͻ���IP��ַ" + client.getInetAddress().getHostAddress());

		// ���ͻ�����Ӧ
		DataOutputStream dos = new DataOutputStream(client.getOutputStream());
		if ("tedu".equals(user.getName()) && "tedu".equals(user.getPassword())) {
			dos.writeUTF("��¼�ɹ�");
		} else {
			dos.writeUTF("��¼ʧ��");
		}
		// �ر���Դ
		dos.close();

	}
}
