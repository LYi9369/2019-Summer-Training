package Day5_TCP��¼;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

//import cn.tedu.entity.User;

public class Client2 implements Serializable {
	public static void main(String[] args) throws UnknownHostException, IOException {
		// �����ͻ��˶���
		Socket client = new Socket("localhost", 8888);
		ObjectOutputStream oos = new ObjectOutputStream(client.getOutputStream());
		DataInputStream dis = new DataInputStream(client.getInputStream());
		// ��������
		Scanner sc = new Scanner(System.in);
		System.out.println("�����˺ţ�");
		String name = sc.next();
		System.out.println("�������룺");
		String pw = sc.next();
		User u = new User(name, pw);
		oos.writeObject(u);
		String str = dis.readUTF();
		System.out.println(str);
		// �ر���Դ
		dis.close();
		oos.close();
		client.close();

	}
}
