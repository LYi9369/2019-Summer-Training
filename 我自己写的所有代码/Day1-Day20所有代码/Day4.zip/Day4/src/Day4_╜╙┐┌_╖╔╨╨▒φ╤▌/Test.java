package Day4_�ӿ�_���б���;

public class Test {
	public static void main(String[] args) {
		Airplane air = new Airplane();
		air.fly();
		Birds bird = new Birds();
		bird.fly();

	}
}
