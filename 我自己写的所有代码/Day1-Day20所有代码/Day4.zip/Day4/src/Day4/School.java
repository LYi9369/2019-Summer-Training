package Day4;

public class School {
	public static Programmer getProgrammer(String type) {
		// String type ����Ƹ����
		Programmer pro = null;
		if ("ch".equals(type)) {

		}
		return pro;
	}
}
