//package Day18_IP��ѯ;
package Day18_IP查询;

import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;

public class QueryIP {
	public static void main(String[] args) {
		String host = "https://api01.aliyun.venuscn.com";
		String path = "/ip";
		String method = "GET";
		String appcode = "11f711c09207449988a20967d8287ba3";
		Map<String, String> headers = new HashMap<String, String>();
		// �����header�еĸ�ʽ(�м���Ӣ�Ŀո�)ΪAuthorization:APPCODE
		// 83359fd73fe94948385f570e3c139105
		headers.put("Authorization", "APPCODE " + appcode);
		Map<String, String> querys = new HashMap<String, String>();
		querys.put("ip", "110.110.110.110");
		String jsonResult = "";
		try {
			/**
			 * ��Ҫ��ʾ����: HttpUtils���
			 * https://github.com/aliyun/api-gateway-demo-sign
			 * -java/blob/master/src
			 * /main/java/com/aliyun/api/gateway/demo/util/HttpUtils.java ����
			 * 
			 * ��Ӧ�����������
			 * https://github.com/aliyun/api-gateway-demo-sign-java/blob
			 * /master/pom.xml
			 */
			HttpResponse response = HttpUtils.doGet(host, path, method,
					headers, querys);
			jsonResult = EntityUtils.toString(response.getEntity());
			System.out.println(response.toString());
			// ��jsonתΪ����
			JSONObject obj = JSONObject.fromObject(jsonResult);
			Integer ret = (Integer) obj.get("ret");
			System.out.println(ret);
			if (ret.equals(200)) {
				System.out.println("�������data");
				JSONObject obj1 = (JSONObject) obj.get("data");
				System.out.println("��ң�" + obj1.get("country"));
				System.out.println("����" + obj1.get("area"));
				System.out.println("ʡ��:" + obj1.get("region"));
				System.out.println("���У�" + obj1.get("city"));
				System.out.println("��IP��" + obj1.get("long_ip"));
				System.out.println("region_id" + obj1.get("region_id"));
				System.out.println("country_id��" + obj1.get("country_id"));
			} else {
				System.out.println("IP��ַ��ѯʧ��");
			}
			System.out.println(jsonResult);
			// ��ȡresponse��body
			// System.out.println(EntityUtils.toString(response.getEntity()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
