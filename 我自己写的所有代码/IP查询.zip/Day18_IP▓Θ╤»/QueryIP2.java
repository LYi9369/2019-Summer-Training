package Day18_IP查询;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;

/**
 * 
 * @author MI
 * 
 */
public class QueryIP2 {
	public static void main(String[] args) {
		System.out.println("输入要查询的IP");
		IPsearch(new Scanner(System.in).next());
	}

	public static void IPsearch(String IP) {
		String host = "https://api01.aliyun.venuscn.com";
		String path = "/ip";
		String method = "GET";
		String appcode = "11f711c09207449988a20967d8287ba3";
		Map<String, String> headers = new HashMap<String, String>();
		// 最后在header中的格式(中间是英文空格)为Authorization:APPCODE
		// 83359fd73fe94948385f570e3c139105
		headers.put("Authorization", "APPCODE " + appcode);
		Map<String, String> querys = new HashMap<String, String>();
		querys.put("ip", IP);
		String jsonResult = "";
		try {
			/**
			 * 重要提示如下: HttpUtils请从
			 * https://github.com/aliyun/api-gateway-demo-sign
			 * -java/blob/master/src
			 * /main/java/com/aliyun/api/gateway/demo/util/HttpUtils.java 下载
			 * 
			 * 相应的依赖请参照
			 * https://github.com/aliyun/api-gateway-demo-sign-java/blob
			 * /master/pom.xml
			 */
			HttpResponse response = HttpUtils.doGet(host, path, method,
					headers, querys);
			jsonResult = EntityUtils.toString(response.getEntity());
			System.out.println(response.toString());
			// 将json转为对象
			JSONObject obj = JSONObject.fromObject(jsonResult);
			Integer ret = (Integer) obj.get("ret");
			System.out.println(ret);
			if (ret.equals(200)) {
				System.out.println("继续解析data");
				JSONObject obj1 = (JSONObject) obj.get("data");
				System.out.println("国家：" + obj1.get("country"));
				System.out.println("地区：" + obj1.get("area"));
				System.out.println("省份:" + obj1.get("region"));
				System.out.println("城市：" + obj1.get("city"));
				System.out.println("长IP：" + obj1.get("long_ip"));
				System.out.println("region_id" + obj1.get("region_id"));
				System.out.println("country_id：" + obj1.get("country_id"));
			} else {
				System.out.println("IP地址查询失败");
			}
			System.out.println(jsonResult);
			// 获取response的body
			// System.out.println(EntityUtils.toString(response.getEntity()));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}