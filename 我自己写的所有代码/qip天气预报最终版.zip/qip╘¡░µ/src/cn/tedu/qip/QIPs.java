package cn.tedu.qip;

import java.util.HashMap;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSONArray;
//import com.alibaba.fastjson.JSONObject;

import cn.tedu.util.HttpUtils;

public class QIPs {
	public static void main(String[] args) {
		QIPs qip = new QIPs();
		System.out.println(qip.QueryIP("丽江"));
	}

	public String QueryIP(String number) {

		// String host = "http://imobile.market.alicloudapi.com";
		// String path = "/mobile/query";
		// String method = "GET";
		// String appcode = "11f711c09207449988a20967d8287ba3";
		// Map<String, String> headers = new HashMap<String, String>();
		// // 最后在header中的格式(中间是英文空格)为Authorization:APPCODE
		// // 83359fd73fe94948385f570e3c139105
		// headers.put("Authorization", "APPCODE " + appcode);
		// Map<String, String> querys = new HashMap<String, String>();
		// querys.put("number", number);
		//
		//
		//
		String host = "http://saweather.market.alicloudapi.com";
		String path = "/hour24";
		String method = "GET";
		String appcode = "fed001ec92654776bfd921145fb1615b";
		Map<String, String> headers = new HashMap<String, String>();
		// 最后在header中的格式(中间是英文空格)为Authorization:APPCODE
		// 83359fd73fe94948385f570e3c139105
		headers.put("Authorization", "APPCODE " + appcode);
		Map<String, String> querys = new HashMap<String, String>();
		// querys.put("area", "丽江");
		querys.put("area", number);
		querys.put("areaid", "101230506");
		//
		//
		//

		String jsonResult = "";
		String result = "";
		try {

			HttpResponse response = HttpUtils.doGet(host, path, method,
					headers, querys);
			// 获取response的body
			jsonResult = EntityUtils.toString(response.getEntity());
			// 将json转为对象
			JSONObject obj = JSONObject.fromObject(jsonResult);
			// Integer ret = (Integer) obj.get("ret");
			Integer showapi_cres_code = (Integer) obj.get("showapi_res_code");
			// if (ret.equals(200)) {
			if (showapi_cres_code.equals(0)) {
				// JSONObject obj1 = (JSONObject) obj.get("data");
				JSONObject obj1 = (JSONObject) obj.get("showapi_res_body");
				net.sf.json.JSONArray obj2 = obj1.getJSONArray("hourList");
				int count = 0;
				for (int i = 0; i < obj2.length(); i++) {
					// count++;
					JSONObject obj3 = obj2.getJSONObject(i);
					result += "时间：" + obj3.get("time") + "<br/>";
					result += "温度：" + obj3.get("temperature") + "摄氏度" + "<br/>";
					result += "天气：" + obj3.get("weather") + "<br/>";
					result += "风向：" + obj3.get("wind_direction") + "<br/>";
					result += "风速：" + obj3.get("wind_power")
							+ "<br/><br/><br/>";

					count++;
					if (count % 3 == 0) {
						// System.out.println();
						// result += "<br/><br/>";
						result += "  <br/><br/><br/>  ";
					}
					// result += "时间：\t" + obj3.get("time") + "<br/>";
					// result += "温度：\t" + obj3.get("temperature") + "度" +
					// "<br/>";
					// result += "风速：\t" + obj3.get("wind_power") + "<br/>";
					// count++;
					// if (count % 3 == 0) {
					// System.out.println();
					// }
				}
				// result = "您所查询的号码归属地是：" + obj1.get("city") + "<br/>";
				// result += "您查询的号码所在省份是：" + obj1.get("prov") + "<br/>";
				// result += "您查询的ip地址的运营商是：" + obj1.get("isp") + "<br/>";
				// 13907976297
			} else {
				System.out.println("查询失败");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
